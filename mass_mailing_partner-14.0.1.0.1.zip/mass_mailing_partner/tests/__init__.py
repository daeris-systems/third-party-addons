# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import test_mail_mass_mailing_contact, test_res_partner
from . import test_mail_mail_statistics
from . import test_partner_mail_list_wizard
from . import test_mail_mass_mailing_list
from . import test_mail_mass_mailing_list_contact_rel
