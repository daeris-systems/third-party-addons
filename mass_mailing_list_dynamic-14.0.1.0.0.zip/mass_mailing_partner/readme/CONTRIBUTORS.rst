* `Tecnativa <https://www.tecnativa.com>`_:

    * Pedro M. Baeza
    * Rafael Blasco
    * Antonio Espinosa
    * Javier Iniesta
    * Jairo Llopis
    * David Vidal
    * Ernesto Tejeda
    * Victor M.M. Torres
    * Manuel Calero
    * Víctor Martínez

* `Hibou Corp. <https://hibou.io>`_
