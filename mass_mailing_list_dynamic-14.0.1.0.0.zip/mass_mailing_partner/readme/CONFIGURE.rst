At first install, all existing mass mailing contacts are matched against
partners. And also mass mailing statistics are matched using model and res_id.
