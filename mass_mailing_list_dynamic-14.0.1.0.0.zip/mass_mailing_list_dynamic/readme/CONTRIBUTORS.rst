* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis
  * Pedro M. Baeza
  * David Vidal
  * Victor M.M. Torres
  * Víctor Martínez

* `Hibou Corp. <https://hibou.io>`_:

  * Jared Kipe <jared@hibou.io>
